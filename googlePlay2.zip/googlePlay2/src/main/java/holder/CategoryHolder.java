package holder;

import android.view.View;
import base.BaseHolder;
import bean.CategoryInfoBean;

public class CategoryHolder extends BaseHolder<CategoryInfoBean> {

	@Override
	public View initHolderView() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void refreshHolderView(CategoryInfoBean data) {
		// TODO Auto-generated method stub
		
	}

}//End
