package bean;

import java.util.List;

public class HomeBean {
	//App列表
	public List<AppInfoBean> list;
	//轮播图图片
	public List<String> picture;
	
}//End
