package bean;

public class SubjectInfoBean {
	
	//专题的描述
	public String des;
	//专题的Url
	public String url;
	
}//End
