package bean;

public class CategoryInfoBean {
	public String title;   //title
	public String name1;   //分类的名称
	public String name2;   //
	public String name3;   //
	public String url1;    //分类的url
	public String url2;    //
	public String url3;    //
	public boolean isTitle;//自己添加的属性，判断是否是title
}//end
